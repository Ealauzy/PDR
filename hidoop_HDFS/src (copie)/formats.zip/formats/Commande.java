package formats;

public enum Commande {CMD_WRITE, CMD_READ, CMD_DELETE};
