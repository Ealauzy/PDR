package formats;

public interface FormatReader {
	public KV read();
}
