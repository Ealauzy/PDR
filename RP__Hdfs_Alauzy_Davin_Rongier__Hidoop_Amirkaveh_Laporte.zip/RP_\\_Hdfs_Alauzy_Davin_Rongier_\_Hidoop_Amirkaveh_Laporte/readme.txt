Le dossier hidoop_HDFS contient les codes et rapport de la partie 1.1 écrits par le trinôme Estelle Alauzy, Marie Davin et Chloé Rongier.

Le dossier hidoop_HIDOOP contient les codes et rapport de la partie 1.2 écrits par Chervin Amirkaveh et Adrien Laporte.

--> Les classes du dossier Format ont été implémentées différemment par chaque binôme/trinôme, une uniformisation sera bien sûr réalisée pour le prochian rendu.


