package config;

public class Project {

	public static String PATH = "/home/";
	
	public static int NBRDATANODE = 3;
	
	public static int PORT[] = {4001,4002,4003};
	
	public static String HOST[] = {"localhost", "localhost", "localhost"};
}
