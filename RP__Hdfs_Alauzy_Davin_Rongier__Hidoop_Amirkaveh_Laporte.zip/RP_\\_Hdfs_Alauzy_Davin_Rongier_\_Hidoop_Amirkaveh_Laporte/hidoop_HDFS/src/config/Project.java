package config;

public class Project {

	public static final String PATH = "~/2A/GLS/Projet/hidoop";

}
